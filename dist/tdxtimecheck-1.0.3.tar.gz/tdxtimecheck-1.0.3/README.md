# tdxtimecheck

A simple CLI tool to calculate worked vs target hours.

## Installation

```bash
pip install tdxtimecheck
